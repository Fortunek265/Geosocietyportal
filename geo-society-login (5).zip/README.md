# Geo Society Login

This project contains a simple authentication setup with:
- Node.js + Express backend
- MongoDB database
- Basic frontend HTML

## Setup
1. cd backend
2. npm install
3. Configure .env
4. npm run dev
