export const protect = (req, res, next) => {
  // Placeholder for auth middleware
  next();
};
